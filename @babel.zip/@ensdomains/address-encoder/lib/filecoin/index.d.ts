/// <reference types="node" />
export declare function filAddrEncoder(data: Buffer): string;
export declare function filAddrDecoder(data: string): Buffer;
