export declare function ensNormalize(name: string): string;
export declare function isValidName(name: string): boolean;
export declare function namehash(name: string): string;
export declare function dnsEncode(name: string): string;
//# sourceMappingURL=namehash.d.ts.map