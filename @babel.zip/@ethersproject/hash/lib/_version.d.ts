export declare const version = "hash/5.7.0";
//# sourceMappingURL=_version.d.ts.map