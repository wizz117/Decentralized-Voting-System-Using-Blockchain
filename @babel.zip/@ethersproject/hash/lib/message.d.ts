import { Bytes } from "@ethersproject/bytes";
export declare const messagePrefix = "\u0019Ethereum Signed Message:\n";
export declare function hashMessage(message: Bytes | string): string;
//# sourceMappingURL=message.d.ts.map