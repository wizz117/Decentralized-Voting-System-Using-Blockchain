export const version = "bignumber/5.7.0";
