export const AddressZero = "0x0000000000000000000000000000000000000000";
//# sourceMappingURL=addresses.js.map