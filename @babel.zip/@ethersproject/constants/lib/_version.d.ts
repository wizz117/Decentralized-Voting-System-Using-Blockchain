export declare const version = "constants/5.7.0";
//# sourceMappingURL=_version.d.ts.map