// NFKC (composed)             // (decomposed)
export const EtherSymbol = "\u039e";  // "\uD835\uDF63";
