import { eipsType } from './../types';
export declare const EIPs: eipsType;
