import { Chain, chainsType } from './../types';
/**
 * @hidden
 */
export declare function _getInitializedChains(customChains?: Chain[]): any;
/**
 * @deprecated this constant will be internalized (removed)
 * on next major version update
 */
export declare const chains: chainsType;
