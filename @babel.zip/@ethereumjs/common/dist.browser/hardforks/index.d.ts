export declare const hardforks: any[][];
