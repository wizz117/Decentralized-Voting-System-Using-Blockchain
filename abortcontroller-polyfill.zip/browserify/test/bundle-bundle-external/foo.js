var bar = require('./bar');
assert.equal(bar, 'bar');

module.exports = 'foo';
done();
