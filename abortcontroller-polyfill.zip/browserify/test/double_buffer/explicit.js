module.exports = require('buffer').Buffer
