ex(require('./beep.json'));
ex(require('./beep'));
