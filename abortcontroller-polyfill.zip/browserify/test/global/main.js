t.equal(a, 555);
t.equal(a, global.a);
