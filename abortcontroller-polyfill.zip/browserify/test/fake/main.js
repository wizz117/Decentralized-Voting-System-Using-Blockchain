var fs = require('fs');
t.equal(fs.party(), 'PaRtY!1!1!');
