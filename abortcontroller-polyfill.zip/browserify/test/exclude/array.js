t.throws(function () { require('./skip.js') });
t.throws(function () { require('./skip2.js') });
