times ++;
t.equal(times, 2);
