times ++;
t.equal(times, 1);
